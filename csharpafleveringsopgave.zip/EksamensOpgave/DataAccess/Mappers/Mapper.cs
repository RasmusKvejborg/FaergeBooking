﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Mappers
{
    internal class Mapper
    {


        public static DTO.Model.Guest Map(Guest guest) // tager DataAcces.guest som parameter og returnerer Guest i DTO
        {
            return new DTO.Model.Guest(guest.name, guest.gender, guest.isDriver, guest.Id);
        }

        public static Guest Map(DTO.Model.Guest guest) // den anden vej rundt
        {
            return new Guest(guest.name, guest.gender, guest.isDriver, guest.Id);
        }

        public static DTO.Model.Car MapCarWithGuests(Car car) 
        {
            return new DTO.Model.Car(car.Id, car.regNumber, MapAllGuests(car.guests), car.FerryId);
        }


        public static DTO.Model.CarOverview MapCar(Car car)
        {
            return new DTO.Model.CarOverview(car.Id, car.regNumber, car.FerryId);
        }

        public static Car MapCar(DTO.Model.Car car)
        {
            var c = new Car(car.Id, car.regNumber, MapAllGuests(car.guests), car.FerryId);
            return c;
        }

        public static List<DTO.Model.CarOverview> MapCars (List<Car> cars)
        {
            List<DTO.Model.CarOverview> list = new List<DTO.Model.CarOverview>();
            foreach (Car car in cars)
            {
                list.Add(MapCar(car));
            }
            return list;
        }

        //public static List<DTO.Model.Car> MapCarsWithGuests(List<Car> cars)
        //{
        //    List<DTO.Model.Car> list = new List<DTO.Model.Car>();
        //    foreach (Car car in cars)
        //    {
        //        list.Add(MapCar(car));
        //    }
        //    return list;
        //}

        public static List<Guest> MapAllGuests(List<DTO.Model.Guest> guests)
        {
            List<Guest> list = new List<Guest>();
            foreach(DTO.Model.Guest guest in guests)
            {
                list.Add(Map(guest));
            }
            return list;
        }

        public static List<DTO.Model.Guest> MapAllGuests(List<Guest> guests)
        {
            List<DTO.Model.Guest> list = new List<DTO.Model.Guest>();
            foreach (Guest guest in guests)
            {
                list.Add(Map(guest));
            }
            return list;
        }

        public static DTO.Model.Ferry MapFerry(Ferry ferry)// tager DataAcces.Ferry som parameter og returnerer Ferry i DTO
        {

            DTO.Model.Ferry ferry1 = new DTO.Model.Ferry(ferry.FerryId, ferry.name, ferry.carPrice, ferry.guestPrice, ferry.maxCars, ferry.maxGuests);
            ferry1.cars = MapCars(ferry.cars);
            return ferry1;
        }

        public static Ferry MapFerry(DTO.Model.Ferry ferry) // den anden vej rundt
        {
            return new Ferry(ferry.Id, ferry.name, ferry.carPrice, ferry.guestPrice, ferry.maxCars, ferry.maxGuests);
        }

        internal static void Update(DTO.Model.Ferry ferry, Ferry dataFerry)
        {
            dataFerry.name = ferry.name;
            dataFerry.maxCars = ferry.maxCars;
            dataFerry.maxGuests = ferry.maxGuests;
            dataFerry.guestPrice = ferry.guestPrice;
            dataFerry.carPrice = ferry.carPrice;

        }




    }
}
