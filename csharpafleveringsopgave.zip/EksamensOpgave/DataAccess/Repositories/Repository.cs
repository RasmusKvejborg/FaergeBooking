﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class Repository
    {

        //public static List<DTO.Model.Car> getCars(int ferryId)
        //{
        //    using (Context.Context context = new Context.Context())
        //    {
        //         var ferry = context.ferries.Find(ferryId);

        //         var cars = ferry.cars.ToList();

        //        return Mappers.Mapper.MapCars(cars);
        //    }
        //}

        public static DTO.Model.Guest getGuest(int id)
        {
        using (Context.Context context = new Context.Context())
            {
                return Mappers.Mapper.Map(context.guests.Find(id));
            }
        }


        public static DTO.Model.Ferry getFerry(int id)
        {
            using (Context.Context context = new Context.Context())
            {
                return Mappers.Mapper.MapFerry(context.ferries.Where(f => f.FerryId == id).Include(f => f.cars).First());
            }
        }

        public static void addGuest(DTO.Model.Guest guest)
        {
            using (Context.Context context = new Context.Context())
            {
                context.guests.Add(Mappers.Mapper.Map(guest));
                context.SaveChanges();
            }
        }

        public static void addCar(DTO.Model.Car car)
        {
            using (Context.Context context = new Context.Context())
            {
                context.cars.Add(Mappers.Mapper.MapCar(car));
                context.SaveChanges();
            }
        }


        public static void updateFerry(DTO.Model.Ferry ferry)
        {
            using (Context.Context context = new Context.Context())
            {



                Ferry dataFerry = context.ferries.Find(ferry.Id);
                Mappers.Mapper.Update(ferry, dataFerry);

                context.SaveChanges();
            }
        }


        public static void deleteGuest(int guestId)
        {
            using (Context.Context context = new Context.Context())
            {
                Guest guest = context.guests.Where(e => e.Id == guestId).FirstOrDefault();
                context.guests.Remove(guest);
            }
        }




        //public static List<CompanyOverview> AllCompanies()
        //{
        //    List<CompanyOverview> retur = new List<CompanyOverview>();
            //using (Context.Context context = new Context.Context())
        //    {
        //        foreach (Model.Company c in context.Companys)
        //        {
        //            retur.Add(GuestMapper.Map(c));
        //        }
        //    }
        //    return retur;
        //}

    }
}
