﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Context
{
    internal class Context : DbContext
    {

        public Context()
        {
            bool created = Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=RASMUS-K-PC\\SQLEXPRESS;Initial Catalog=Ferries;Integrated Security=SSPI; TrustServerCertificate=true");
            optionsBuilder.LogTo(message => Debug.WriteLine(message));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) // laver startdata
        {
            modelBuilder.Entity<Ferry>().HasData(new Ferry[] {
            new Ferry(1, "NolsLinjen",197,99,13,40),
            new Ferry(2, "Stener Line", 197, 99, 20, 70),
        });
        }

        public DbSet<Ferry> ferries { get; set; }
        public DbSet<Car> cars { get; set; }
        public DbSet<Guest> guests { get; set; }

    }
}
