﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    internal class Ferry
    {
        public int FerryId { get; set; }
        public string name { get; set; }
        public int carPrice { get; set; }
        public int guestPrice { get; set; }
        public int maxCars { get; set; }
        public int maxGuests { get; set; }



        public List<Car> cars { get; set; }

        public List<Guest> guests { get; set; }

        public Ferry() { }
        public Ferry(int Id, string name, int carPrice, int guestPrice, int maxCars, int maxGuests)
        {
            this.FerryId = Id;
            this.name = name;
            this.carPrice = carPrice;
            this.guestPrice = guestPrice;
            this.maxCars = maxCars;
            this.maxGuests = maxGuests;
        }
    }

}


