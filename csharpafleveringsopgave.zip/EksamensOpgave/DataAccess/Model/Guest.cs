﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{


    internal class Guest
    {
        public string name {  get; set; }
        public string gender { get; set; } 
        public bool isDriver { get; set; }
        public int Id { get; set; }


        //public Car car { get; set; } laver den lige enkeltrettet

        public Guest() { }


        public Guest(string name, string gender, bool isDriver, int Id)
        {
            this.name = name;
            this.gender = gender;
            this.isDriver = isDriver;
            this.Id = Id;

    }
}
}
