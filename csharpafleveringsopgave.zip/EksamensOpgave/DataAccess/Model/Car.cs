﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO.Model;

namespace DataAccess
{
    internal class Car
    {
        public int Id { get; set; }
        public string regNumber {  get; set; }

        public List<Guest> guests { get; set; }

        public int FerryId { get; set; }
        public Car() { }

        public Car(int Id, string regNumber, List<Guest> guests, int FerryId)
        {
            this.Id = Id;
            this.regNumber = regNumber;
            this.guests = guests;
            this.FerryId = FerryId;
        }
    }
}
