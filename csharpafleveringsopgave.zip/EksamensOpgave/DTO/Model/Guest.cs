﻿using System.Reflection;

namespace DTO.Model
{

    public class Guest
    {

        public string name { get; set; }
        public string gender { get; set; }
        public bool isDriver { get; set; }
        public int Id { get; set; }

        public Guest() { }

        public Guest(string name, string gender, bool isDriver, int Id)
        {
            this.name = name;
            this.gender = gender;
            this.isDriver = isDriver;
            this.Id = Id;
        }
    }
}