﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO.Model
{
    public class CarOverview
    {
        public int Id { get; set; }
        public string regNumber { get; set; }

        public int FerryId { get; set; }

        public CarOverview() { }
        public CarOverview(int Id, string regNumber, int FerryId)
        {
            this.Id = Id;
            this.regNumber = regNumber;
            this.FerryId = FerryId;
        }
    }
}
