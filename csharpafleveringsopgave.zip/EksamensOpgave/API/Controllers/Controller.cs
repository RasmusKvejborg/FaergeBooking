﻿using DTO.Model;
using Microsoft.AspNetCore.Mvc;
using BusinessLogic.BLL;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Controller : ControllerBase
    {
        [HttpGet]
        [Route("/guest/{id}")]

        public Guest GetGuest(int id)
        {
            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();
            return bll.getGuest(id);
        }


        [HttpGet]
        [Route("/ferry/{id}")]
        public Ferry GetFerry(int id)
        {
            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();
            return bll.getFerry(id);
        }


    }
}






   