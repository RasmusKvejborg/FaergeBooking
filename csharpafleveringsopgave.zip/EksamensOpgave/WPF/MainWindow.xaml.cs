﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DTO.Model;

namespace WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {

            InitializeComponent();

            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();

            Ferry ferry = bll.getFerry(1);

            ferryName.Content = ferry.name;

            maxCars.Content = ferry.maxCars;

            maxGuests.Content = ferry.maxGuests;

            carPrice.Content = ferry.carPrice;

            guestPrice.Content =  ferry.guestPrice;

     


        }





        private void Button_Click(object sender, RoutedEventArgs e)
        {


            if (!int.TryParse(GuestID.Text, out _)) // forsøger at parse GuestID til en int, og hvis ikke muligt, så returner den.
            {
                guestName.Content = "Indtast et gyldigt ID";
                return;
            }


                try
                { 
            HttpClient client = new HttpClient();
            var msg = client.GetStringAsync($"https://localhost:7080/guest/" + GuestID.Text).Result; 

            DTO.Model.Guest guest = JsonSerializer.Deserialize<DTO.Model.Guest>(msg);



            guestName.Content = "navn: " + guest.name.ToString();


            }
                catch (Exception ex) { guestName.Content = "Noget gik galt"; }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            if (!int.TryParse(nytMaxCars.Text, out _)) // validering af at det er en int
            {
                response.Content = "Indtast et gyldigt antal";
                return;
            }

            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();

            Ferry ferry = bll.getFerry(1);

            ferry.maxCars = int.Parse(nytMaxCars.Text);

            maxCars.Content = ferry.maxCars; // blot lige så man kan se ændringen med det samme, det gemmes også nede i databasen, så ændringen ses også næste gang man kører programmet.
            response.Content = "Max antal biler ændret";
            nytMaxCars.Text = "";

            bll.updateFerry(ferry);



        }
    }
}
