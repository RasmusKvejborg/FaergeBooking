﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using BusinessLogic;
using BusinessLogic.BLL;
using DTO.Model;
using System.Security.Cryptography;

namespace MVC.Controllers
{
    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();


            Ferry ferry = bll.getFerry(1);

            ViewBag.cars = ferry.cars;

            return View(ferry);
        }

        public IActionResult CreateCar()
        {
            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();


            Ferry ferry = bll.getFerry(1);

            ViewBag.cars = ferry.cars;

            ViewBag.maxCars = ferry.maxCars;

            return View();
        }



        public IActionResult deleteCar(int carId)
        {

            // Console.WriteLine("test"); 
            // delete...

           return RedirectToAction("Index"); 

        }


        public IActionResult addCar(String regNumber, String driverName, String driverGender) // bruger binding så jeg ikke behøver bruge IformCollection.
        {
            

            BusinessLogic.BLL.BusinessLogic bll = new BusinessLogic.BLL.BusinessLogic();

            var driver = new Guest(driverName, driverGender, true, 0);

            var guestList = new List<Guest>();

            guestList.Add(driver);

            var car = new Car(0, regNumber, guestList, 1);

            bll.addCar(car);

            return RedirectToAction("CreateCar");

        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}