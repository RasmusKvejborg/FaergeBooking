﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO.Model;
using DataAccess.Repositories;

namespace BusinessLogic.BLL
{
    public class BusinessLogic
    {
        
        // public List<Car> getCars(int ferryId) {
        //     return Repository.getCars(ferryId);
        //}

        public Guest getGuest(int id)
        {
            if (id < 0) throw new IndexOutOfRangeException(); // kaster en fejl hvis id er under 0
            return Repository.getGuest(id);
        }

        public Ferry getFerry(int id)
        {
            if (id < 0) throw new IndexOutOfRangeException(); // kaster en fejl hvis id er under 0
            return Repository.getFerry(id);
        }


        public void addGuest (Guest guest)
        {
            Repository.addGuest(guest);
        }

        public void addCar(Car car)
        {
            Repository.addCar(car);
        }

        public void removeGuest (int id)
        {
            Repository.deleteGuest(id);
        }

        public void updateFerry(Ferry ferry) { 
        
            Repository.updateFerry(ferry);
        }



        //public List<CompanyOverview> AllCompanies()
        //{
        //    return EmployeeRepository.AllCompanies();
        //}


        //public void AddEmployeeToCompany(int EmployeeId, int CompanyId) // kunne være der blev brug for at adde folk til deres biler???
        //{
        //    EmployeeRepository.AddEmployeeToCompany(EmployeeId, CompanyId);
        //}


    }
}
